package com.factory.pattern;

public interface Shape {
	void draw();
}
